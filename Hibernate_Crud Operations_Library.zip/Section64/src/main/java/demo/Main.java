package demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try
{ 
	 SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	 Session session = sessionFactory.openSession();
     Transaction t;
     
     Library ob1=new Library();
   
     //Insertion
 //------------------------------------------------------------    
    // ob1.setBno(1);
     //ob1.setBname("Java");
    // ob1.setPages(200);
     
//insert 1st record     
    // t=session.beginTransaction();
     //session.save(ob1);
    // t.commit();
        
   // ob1.setBno(2);
   //  ob1.setBname("dotnet");
   //  ob1.setPages(250);
   //  t=session.beginTransaction();
  //   session.save(ob1);
    // t.commit();
 //---------------------------------------------------------
//retrieve
     	Library ob=session.find(Library.class, 1);
     	System.out.println(ob);
 //--------------------------------------------
    ob.setBname("Java Technologies");
   //update
    t=session.beginTransaction();
    session.update(ob);
    t.commit();
   //delete  
    t=session.beginTransaction();
       session.delete(ob);
      t.commit();
}
finally {}
	}

}
